"""NumPy MLP: (bias + 2 inputs) -> (bias + 2 hidden units) -> 3 outputs.

실행: python mlp_multiclass.py
수업 사진과 강의 슬라이드를 참고한 재구현. 데이터는 새로 생성한 합성 데이터다.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap


def generate_data(n_per_class=100, seed=42):
    """사진과 유사한 2차원 정규분포 세 군집. 라벨은 내부적으로 0, 1, 2."""
    rng = np.random.default_rng(seed)
    centers = np.array([[0.0, 0.0], [4.0, 0.0], [2.0, 4.0]])
    data = np.vstack([rng.normal(center, 1.2, (n_per_class, 2))
                      for center in centers])
    label = np.repeat(np.arange(3), n_per_class)
    order = rng.permutation(len(label))
    return data[order], label[order]


class MLP:
    """강의의 3→3→3은 입력층/은닉층의 bias를 포함한 노드 수이다."""
    def __init__(self, learning_rate=0.1, seed=7):
        self.learning_rate = learning_rate
        rng = np.random.default_rng(seed)
        self.input_hidden_weight = rng.normal(0, 0.5, (3, 2))
        self.hidden_output_weight = rng.normal(0, 0.5, (3, 3))
        self.history = []

    @staticmethod
    def add_bias(data):
        return np.concatenate((np.ones((len(data), 1)), data), axis=1)

    @staticmethod
    def sigmoid(z):
        # exp(-큰 음수)의 overflow를 피하는 안정적인 sigmoid.
        return np.exp(-np.logaddexp(0.0, -z))

    def feedforward(self, learn_data):
        self.learn_data_with_bias = self.add_bias(learn_data)  # N × 3
        hidden_z = self.learn_data_with_bias @ self.input_hidden_weight
        self.hidden_result = self.sigmoid(hidden_z)  # N × 2
        self.hidden_result_with_bias = self.add_bias(self.hidden_result)
        logits = self.hidden_result_with_bias @ self.hidden_output_weight
        shifted = logits - np.max(logits, axis=1, keepdims=True)
        self.log_probability = shifted - np.log(
            np.sum(np.exp(shifted), axis=1, keepdims=True))
        return np.exp(self.log_probability)  # softmax, N × 3

    def loss_and_gradients(self, learn_data, learn_label):
        """learn_label: one-hot 행렬 N × 3. 가중치 변경 없이 미분한다."""
        output_result = self.feedforward(learn_data)
        loss = -np.mean(np.sum(learn_label * self.log_probability, axis=1))
        # Softmax + categorical cross entropy: dJ/dZ2 = (P - Y) / N
        output_node_gradient = output_result - learn_label
        hidden_output_weight_update = (
            self.hidden_result_with_bias.T @ output_node_gradient / len(learn_data))
        # bias 행은 은닉 뉴런이 아니므로 역전파에서 제외한다.
        hidden_node_error = output_node_gradient @ self.hidden_output_weight[1:].T
        hidden_node_gradient = hidden_node_error * self.hidden_result * (1-self.hidden_result)
        input_weight_update = (
            self.learn_data_with_bias.T @ hidden_node_gradient / len(learn_data))
        return float(loss), input_weight_update, hidden_output_weight_update

    def train(self, learn_data, learn_label, epoch=20000, verbose=True):
        self.history = []
        for i in range(epoch + 1):
            loss, grad_w1, grad_w2 = self.loss_and_gradients(learn_data, learn_label)
            if i % 100 == 0 or i == epoch:
                self.history.append((i, loss))
            if verbose and (i % 2000 == 0 or i == epoch):
                print(f"Epoch {i:5d} | loss = {loss:.6f}")
            if i == epoch:
                break
            # 두 gradient를 같은 시점의 가중치로 계산한 뒤 함께 갱신한다.
            self.input_hidden_weight -= self.learning_rate * grad_w1
            self.hidden_output_weight -= self.learning_rate * grad_w2
        return self

    def predict(self, data):
        return np.argmax(self.feedforward(data), axis=1)


def confusion_matrix(actual, predicted):
    result = np.zeros((3, 3), dtype=int)
    np.add.at(result, (actual, predicted), 1)
    return result


def gradient_check():
    """15개 가중치 모두 중앙차분 수치미분과 비교한다."""
    data, label = generate_data(n_per_class=2, seed=123)
    target = np.eye(3)[label]
    model = MLP(seed=19)
    _, grad1, grad2 = model.loss_and_gradients(data, target)
    errors = []
    eps = 1e-5
    for weights, analytic in [(model.input_hidden_weight, grad1),
                              (model.hidden_output_weight, grad2)]:
        for index in np.ndindex(weights.shape):
            original = weights[index]
            weights[index] = original + eps
            plus = model.loss_and_gradients(data, target)[0]
            weights[index] = original - eps
            minus = model.loss_and_gradients(data, target)[0]
            weights[index] = original
            errors.append(abs((plus-minus)/(2*eps)-analytic[index]))
    maximum_error = float(max(errors))
    assert maximum_error < 1e-6, maximum_error
    return maximum_error


def plot_results(model, data, label, test_cm, out_dir):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    # 사진과 같은 배치/색상. 배경은 실제 모델 예측이고 점은 정답이다.
    xmin, xmax = min(-4.8, data[:, 0].min()-0.4), max(9.0, data[:, 0].max()+0.4)
    ymin, ymax = min(-4.2, data[:, 1].min()-0.4), max(7.8, data[:, 1].max()+0.4)
    xx, yy = np.meshgrid(np.linspace(xmin, xmax, 450), np.linspace(ymin, ymax, 400))
    region = model.predict(np.column_stack((xx.ravel(), yy.ravel()))).reshape(xx.shape)
    fig, ax = plt.subplots(figsize=(9, 7))
    ax.contourf(xx, yy, region, levels=[-0.5, 0.5, 1.5, 2.5],
                cmap=ListedColormap(["#ddddf1", "#f8f8fd", "#f2dada"]))
    ax.contour(xx, yy, region, levels=[0.5, 1.5], colors="#b9b8c5", linewidths=0.6)
    for k, color in enumerate(["#e71933", "#2016e5", "#151515"]):
        mask = label == k
        ax.scatter(data[mask, 0], data[mask, 1], c=color, s=24,
                   label=f"class{k+1}", edgecolors="white", linewidths=0.25, zorder=3)
    wrong = model.predict(data) != label
    ax.scatter(data[wrong, 0], data[wrong, 1], facecolors="none", edgecolors="#4c99b4",
               s=106, linewidths=1.4, label="false", zorder=4)
    ax.set(xlim=(xmin, xmax), ylim=(ymin, ymax), xlabel="$x_1$", ylabel="$x_2$")
    ax.legend(loc="upper right", fontsize=12)
    fig.tight_layout()
    for suffix in ["png", "pdf"]:
        fig.savefig(out_dir / f"decision_boundary.{suffix}", dpi=200)
    plt.close(fig)

    history = np.array(model.history)
    fig, ax = plt.subplots(figsize=(8, 3.6))
    ax.plot(history[:, 0], history[:, 1], color="#285fa8", linewidth=2)
    ax.set(xlabel="Epoch (weight updates)", ylabel="Categorical cross entropy",
           title="Training loss")
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(out_dir / "training_loss.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(5.5, 4.4))
    ax.imshow(test_cm, cmap="Blues", vmin=0)
    for i in range(3):
        for j in range(3):
            ax.text(j, i, str(test_cm[i, j]), ha="center", va="center", fontsize=14,
                    color="white" if test_cm[i,j] > test_cm.max()/2 else "#17243d")
    ax.set(xticks=range(3), yticks=range(3),
           xticklabels=["class1", "class2", "class3"],
           yticklabels=["class1", "class2", "class3"],
           xlabel="Predicted class", ylabel="True class",
           title="Independent synthetic test set (N = 3000)")
    fig.tight_layout()
    fig.savefig(out_dir / "test_confusion_matrix.png", dpi=180)
    plt.close(fig)


def run_experiment(out_dir="outputs"):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    data, label = generate_data(100, seed=42)
    # 학습에 사용하지 않은 동일 분포의 독립 표본. 테스트로 모델을 선택하지 않는다.
    test_data, test_label = generate_data(1000, seed=2026)
    model = MLP(learning_rate=0.1, seed=7)
    model.train(data, np.eye(3)[label], epoch=20000)
    train_pred = model.predict(data)
    test_pred = model.predict(test_data)
    train_cm = confusion_matrix(label, train_pred)
    test_cm = confusion_matrix(test_label, test_pred)
    gradient_error = gradient_check()
    assert model.input_hidden_weight.shape == (3, 2)
    assert model.hidden_output_weight.shape == (3, 3)
    probabilities = model.feedforward(test_data)
    assert np.isfinite(probabilities).all()
    assert np.allclose(probabilities.sum(axis=1), 1.0)
    assert model.history[-1][1] < model.history[0][1]
    assert train_cm.sum() == 300 and test_cm.sum() == 3000

    metrics = {
        "architecture": "(bias+2) -> (bias+2) -> 3",
        "parameters": 15,
        "data_source": "new synthetic Gaussian samples, not original classroom data",
        "centers": [[0, 0], [4, 0], [2, 4]], "std": 1.2,
        "train_seed": 42, "test_seed": 2026, "weight_seed": 7,
        "learning_rate": 0.1, "epochs": 20000,
        "train_count": len(label), "test_count": len(test_label),
        "initial_loss": model.history[0][1], "final_loss": model.history[-1][1],
        "test_loss": model.loss_and_gradients(test_data, np.eye(3)[test_label])[0],
        "train_accuracy": float(np.mean(train_pred == label)),
        "test_accuracy": float(np.mean(test_pred == test_label)),
        "train_errors": int(np.sum(train_pred != label)),
        "test_errors": int(np.sum(test_pred != test_label)),
        "train_confusion_matrix": train_cm.tolist(),
        "test_confusion_matrix": test_cm.tolist(),
        "gradient_check_max_absolute_error": gradient_error,
    }
    for name, x, y, pred in [("train", data, label, train_pred),
                              ("test", test_data, test_label, test_pred)]:
        np.savetxt(out_dir / f"{name}_predictions.csv",
                   np.column_stack((x, y+1, pred+1)), delimiter=",",
                   header="x1,x2,true_class,predicted_class", comments="",
                   fmt=["%.10f", "%.10f", "%d", "%d"])
    np.savez(out_dir / "weights.npz", W1=model.input_hidden_weight,
             W2=model.hidden_output_weight)
    with np.load(out_dir / "weights.npz") as saved:
        restored = MLP()
        restored.input_hidden_weight = saved["W1"]
        restored.hidden_output_weight = saved["W2"]
    assert np.array_equal(restored.predict(test_data), test_pred)
    (out_dir / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    np.savetxt(out_dir / "loss_history.csv", model.history, delimiter=",",
               header="epoch,loss", comments="", fmt=["%d", "%.10f"])
    plot_results(model, data, label, test_cm, out_dir)
    print(f"Train accuracy: {metrics['train_accuracy']:.2%} ({metrics['train_errors']} errors / 300)")
    print(f"Test accuracy:  {metrics['test_accuracy']:.2%} ({metrics['test_errors']} errors / 3000)")
    print(f"Gradient check max absolute error: {gradient_error:.3e}")
    return metrics


if __name__ == "__main__":
    run_experiment(Path(__file__).resolve().parent / "outputs")
