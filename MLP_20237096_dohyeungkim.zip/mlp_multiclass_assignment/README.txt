MLP 다중 클래스 분류 실습 — 20237096 dohyeungkim

바로 볼 파일
  Report_20237096_dohyeungkim.pdf   한글 보고서 5쪽
  Report_20237096_dohyeungkim.docx  편집용 보고서
  MLP_20237096_dohyeungkim.ipynb    실행 결과가 포함된 Colab/Jupyter 노트북
  outputs/decision_boundary.png   사진처럼 만든 결정 영역과 오분류 그래프

Colab에서 실행
  1. Google Colab에서 MLP_20237096_dohyeungkim.ipynb를 업로드한다.
  2. 런타임 → 모두 실행을 누른다. CPU로 실행 가능하다.
  3. 데이터, 코드, 학습, 그래프가 모두 포함되어 별도 소스 파일은 필요 없다.
  4. 결과는 Colab의 outputs 폴더에 생성된다.

로컬에서 실행 (Python 3.10 이상)
  python -m venv .venv
  source .venv/bin/activate
  python -m pip install -r requirements.txt
  python mlp_multiclass.py
  Windows에서 가상환경 활성화: .venv\Scripts\activate

구현과 데이터
  입력 특징 2개 + bias → 은닉 sigmoid 뉴런 2개 + bias → softmax 출력 3개.
  강의자료의 3→3→3 표기는 입력층/은닉층의 편향을 포함한다.
  가중치는 3×2와 3×3, 총 15개이다.
  원본 소스와 데이터가 없어 사진 및 로컬 강의 PDF를 바탕으로 재구현했다.
  합성 데이터의 평균은 (0,0), (4,0), (2,4), 각 축 표준편차는 1.2이다.
  사진과 점 좌표 및 결정 경계가 완전히 같지는 않다.
  학습 데이터 300개(seed=42), 독립 평가 데이터 3,000개(seed=2026).
  초기 가중치 seed=7, 학습률=0.1, epoch=20,000.

실제 실행 결과
  학습 정확도 94.00% (282/300), 오분류 18개.
  독립 평가 정확도 92.77% (2,783/3,000), 오분류 217개.
  학습 손실: 1.171551 → 0.154325.
  역전파 수치미분 검증: 최대 절대 오차 약 2.103e-11 (허용치 1e-6).
  테스트는 동일 합성 분포에서 새로 생성한 데이터에 대한 평가이다.

outputs 파일
  decision_boundary.png / .pdf : 배경=모델 예측, 점=정답, false=오분류
  training_loss.png            : 학습 손실 곡선
  test_confusion_matrix.png    : 행=정답, 열=예측인 독립 평가 혼동행렬
  train_predictions.csv       : 학습 좌표, 정답, 예측 (클래스 번호 1~3)
  test_predictions.csv        : 평가 좌표, 정답, 예측 (클래스 번호 1~3)
  loss_history.csv            : 100 epoch마다 기록한 손실
  weights.npz                 : 학습된 W1, W2
  metrics.json                : 설정과 실행 지표

소스의 run_experiment()에서 학습 설정을 바꿀 수 있다.
다시 실행하면 outputs 결과 파일이 갱신된다. PDF/DOCX 보고서는 자동 갱신되지 않는다.
학습 설정을 바꾼 경우 보고서의 수치와 그림도 새 결과에 맞게 수정해야 한다.
검증 환경: Python 3.14.3, NumPy 2.4.4, Matplotlib 3.11.2.
운영체제 및 라이브러리 버전에 따라 부동소수점의 마지막 자릿수는 달라질 수 있다.

참고: 제공된 수업 사진, 5_딥러닝이론및응용.pdf,
6_2_딥러닝이론및응용.pdf (10쪽 softmax, 14쪽 행렬 구조, 21쪽 과제, 22쪽 예시).
